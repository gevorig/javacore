package lessonSix;

public class Cat extends Animals{
    public Cat (String nickname, int run, int swim) {super(nickname, run, swim);}

    @Override
    public void doAction() {
        System.out.printf("%s бегает  %n", super.getNickname());}
}
