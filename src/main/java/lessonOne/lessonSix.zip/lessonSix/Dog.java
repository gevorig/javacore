package lessonSix;

public class Dog extends Animals{
    public Dog(String nickname, int run, int swim) {super(nickname, run, swim);}
    public void doAction() {
        System.out.printf("%s бегает и плавает %n", nickname);
    }
}
