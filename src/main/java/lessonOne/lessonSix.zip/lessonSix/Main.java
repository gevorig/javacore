package lessonSix;

public class Main {
    public static void main(String[] args) {
        int score = 0;
        Dog dog = new Dog("Бобик", 150, 10);
        Cat cat = new Cat("Барсик", 175, 0);
        Animals cat2 = new Cat("Марсик", 95, 0);
        Animals[] animalss = {dog,cat,cat2};
        for (int i = 0; i < animalss.length; i++) {
            score++;

        }

        for (Animals animals: animalss) {
            animals.printInfo();

            animals.doAction();
            System.out.println("========================");
        }
        System.out.println("Всего животных: " + score);

    }
}
