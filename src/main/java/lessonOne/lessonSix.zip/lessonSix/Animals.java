package lessonSix;

public abstract class Animals extends Object {
    protected String nickname;
    private int run;
    private int swim;
    public int score;

    public Animals(String nickname, int run, int swim){
        this.nickname = nickname;
        this.run = run;
        this.swim = swim;
        score++;
    }

    /*public Animals(String nickname, int run) {

    }*/

    public String getNickname() {return nickname;}
    public void setNickname(String nickname) {this.nickname = nickname;}
    public int getRun() {return run;}
    public void setRun(int run) {this.run = run;}
    public int getSwim() { return swim;}
    public void setSwim(int swim) {this.swim = swim;}
    @Override
    public String toString() { return String.format("%s пробежал %d метров и проплыл %d метров%n", nickname, run, swim); }
    public void printInfo() { System.out.println(this); }
    public abstract void doAction();
}
